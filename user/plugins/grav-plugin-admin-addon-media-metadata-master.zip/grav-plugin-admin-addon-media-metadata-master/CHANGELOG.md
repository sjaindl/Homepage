# v1.0.2
##  16-04-2020

1. [](#improved)
    * The button next to a media file will now also be translated. It was hard-coded to English before.

# v1.0.1
##  10-04-2020

1. [](#bugfix)
    * meta.yaml file will now be created for an already uploaded media file that did not have an associated meta.yaml file before

# v1.0.0
##  20-03-2020

1. [](#improved)
    * using core technology (Grav\Common\Yaml) for parsing and writing the meta.yaml files – kudos to https://github.com/renards for adding crucial parts to the code

# v0.9.1
##  16-03-2020

1. [](#bugfix)
    * adding /vendor/ and composer.lock, needed for composer autoload functionality

# v0.9.0
##  15-03-2020

1. [](#new)
    * Initial release