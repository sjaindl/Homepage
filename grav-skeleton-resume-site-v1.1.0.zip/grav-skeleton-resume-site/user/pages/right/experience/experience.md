---
title: EXPERIENCE
date: 13:34 06/21/2014 

experience:
  - date: From 2013 to 2014
    role: Art Director.
    company: Distrito 01 (d01 .es)
    years: 2
    animation: fadeIn
  - date: From 2009 to July 2014
    role: Graphics & Web.
    company: Freelance.
    years: 6
    animation: fadeIn

taxonomy:
    category: right
---
