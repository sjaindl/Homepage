---
title: Hobbies & Interests
date: 13:34 02/21/2014 

interests:
    - icon: camera
      activity: Photography
      animation: fadeIn
    - icon: mountains
      activity: Hiking
      animation: fadeIn  
    - icon: book
      activity: Reading
      animation: fadeIn   
    - icon: music
      activity: Music
      animation: fadeIn   
    - icon: trees
      activity: Walking
      animation: fadeIn    
    - icon: paw
      activity: Dogs
      animation: fadeIn    
    - icon: die-six
      activity: Games
      animation: fadeIn  
    - icon: ticket
      activity: Theatre
      animation: fadeIn   


taxonomy:
    category: right
---
