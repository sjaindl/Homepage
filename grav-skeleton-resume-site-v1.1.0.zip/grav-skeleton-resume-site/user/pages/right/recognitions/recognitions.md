---
title: Recognitions
date: 13:34 06/21/2014 

recognitions:
    - title: Remus Logo Design.
      desc: Internal contest. One of the three finalists.
      place: Universidad Antonio de Nebrija. Madrid
      position: 1-3
      animation: fadeIn
    - title: Vino de Toro Label Design.
      desc: National contest. One of the 15 finalists.
      place: Vino de Toro.
      position: 2-15
      animation: fadeIn  

taxonomy:
    category: right
---
