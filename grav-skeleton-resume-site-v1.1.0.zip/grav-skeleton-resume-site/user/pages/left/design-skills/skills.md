---
title: DESIGN SKILLS
date: 13:34 04/21/2014

column1_name: 01 Computer
column1_animation: fadeIn
column2_name: 02 Knowledge
column2_animation: fadeIn

column1:
  - name: Adobe Photoshop
    level: 8
  - name: Adobe Illustrator
    level: 8  
  - name: Adobe Indesign
    level: 6  
  - name: Adobe Flash
    level: 7  
  - name: "HTML & CSS"
    level: 8 
  - name: "Javascript & Jquery"
    level: 3
  - name: AutoCad
    level: 8
  - name: CATIA
    level: 8 
  - name: 3ds Max
    level: 3
  - name: Cinema 4D
    level: 4           

column2:
  - name: Grid & Layout.
  - name: Good sense for typography.
  - name: Color theory knowledge.
  - name: Web usability.
  - name: Interface Design.
  - name: Google Analytics & SEO.
    
taxonomy:
    category: left
---
