---
title: LANGUAGE SKILLS
date: 13:34 02/21/2014

languages:
  - name: Spanish
    level_name: Mother Language
    level: 100
    animation: bounceIn
  - name: English
    level_name: Advanced Level
    level: 75  
    animation: bounceIn
  - name: French
    level_name: Basic Level
    level: 25  
    animation: bounceIn
    
taxonomy:
    category: left
---
