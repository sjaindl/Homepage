---
title: MY SPECIALITIES
date: 13:34 05/21/2014 
specialities:
    - icon: lightbulb
      text: Logo Design
      animation: fadeInDown
    - icon: page-multiple
      text: Branding 
      animation: fadeInUp
    - icon: results
      text: Minimal Web Design
      animation: fadeInLeft
taxonomy:
    category: left
---
